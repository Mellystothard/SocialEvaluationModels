
batch2f=1; 
homeD = '/home/mmoutou/';
fitD=[ homeD 'Dropbox/BASOR/SocialEvaluationLearning_(SELT)/Carlisi_SELT_pilot1/pil01_fit10b_01/'];
selAIF = [homeD 'Dropbox/BASOR/SocialEvaluationLearning_(SELT)/Carlisi_SELT_pilot1/pil01_fit10b_01/data4sel8bl03.mat']; 
initTrParF=[homeD '/home/mmoutou/Dropbox/BASOR/SocialEvaluationLearning_(SELT)/Carlisi_SELT_pilot1/pil01_fit08b_01/sel_08b_01_1to136_ldat_merged.mat']; 
grN=12; 
grSc=5; 
batchSiz=34; 
p09b01 = SEL2_Grid10b_xiii(selAIF, batch2f, initTrParF, grN, grSc, batchSiz, fitD);

% - % 