
batch2f=7; 
homeD = '/home/mmoutou/';
fitD=[ homeD 'Dropbox/BASOR/SocialEvaluationLearning_(SELT)/Carlisi_SELT_pilot1/pil01_fit08b_01/'];
selAIF = [homeD 'Dropbox/BASOR/SocialEvaluationLearning_(SELT)/Carlisi_SELT_pilot1/pil01_fit08b_01/data4sel8bl03.mat']; 
initTrParF=[homeD 'googledirs/MM/SocEvalModels_(not_git)_rough_work/dataFits/selGrid04b06Aug/selGrid04b06Aug.mat']; 
grN=12; 
grSc=4; 
batchSiz=20; 
p08b07 = SEL2_Grid08b_xiii(selAIF, batch2f, initTrParF, grN, grSc, batchSiz, fitD);

% - % 